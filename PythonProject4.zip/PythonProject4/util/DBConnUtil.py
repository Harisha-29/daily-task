
# util/DBConnUtil.py
'''import pyodbc
from util.DBPropertyUtil import getPropertyString

class DBConnUtil:
    @staticmethod
    def getConnection():
        props = getPropertyString("C:/Users/haris/PycharmProjects/PythonProject4/dbconfig.properties")

        try:
            conn = pyodbc.connect(
                "DRIVER={SQL Server};"
                "SERVER=HOME;"  # Replace with your actual server name
                "DATABASE=CarRentalDB;"
                "Trusted_Connection=yes;"
            )
            print("✅ Connected successfully!")
            conn.close()
        except Exception as e:
            print("❌ Connection failed:", e)'''
import pyodbc

'''
import pyodbc
from util.DBPropertyUtil import getPropertyString

class DBConnUtil:
    @staticmethod
    def getConnection():
        try:
            props = getPropertyString("C:/Users/haris/PycharmProjects/PythonProject4/dbconfig.properties")

            if props.get('trusted_connection', 'no').lower() == 'yes':
                conn_str = (
                    f"DRIVER={props['driver']};"
                    f"SERVER={props['server']},{props['port']};"
                    f"DATABASE={props['database']};"
                    f"Trusted_Connection=yes;"
                )
            else:
                conn_str = (
                    f"DRIVER={props['driver']};"
                    f"SERVER={props['server']},{props['port']};"
                    f"DATABASE={props['database']};"
                    f"UID={props['username']};"
                    f"PWD={props['password']};"
                )

            connection = pyodbc.connect(conn_str)
            print("✅ Connected successfully!")
            return connection

        except Exception as e:
            print(f"❌ Database connection failed: {e}")
            return None  # <- this is currently causing your crash in __init__
'''

class DBConnUtil:
    @staticmethod
    def getConnection():
        try:
            conn = pyodbc.connect(
                "DRIVER={SQL Server};"
                "SERVER=HOME;"     # Check this
                "DATABASE=CarRentalDB;"             # Check this
                "Trusted_Connection=yes;"                # Check this
            )
            return conn
        except Exception as e:
            print(f"❌ Database connection failed: {e}")
            return None
