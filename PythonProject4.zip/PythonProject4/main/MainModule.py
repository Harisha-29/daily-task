'''from dao.ICarLeaseRepositoryImpl import ICarLeaseRepositoryImpl
from entity.Car import Car

def main():
    repo = ICarLeaseRepositoryImpl()
    while True:
        print("1. Add Car\n2. List Available Cars\n3. Exit")
        choice = int(input("Enter your choice: "))

        if choice == 1:
            make = input("Make: ")
            model = input("Model: ")
            year = int(input("Year: "))
            rate = float(input("Daily Rate: "))
            status = "available"
            pcap = int(input("Passenger Capacity: "))
            ecap = float(input("Engine Capacity: "))
            car = Car(make=make, model=model, year=year, dailyRate=dailyRate, status=status,
                      passengerCapacity=pcap, engineCapacity=ecap)
            repo.addCar(car)

        elif choice == 2:
            cars = repo.listAvailableCars()
            for car in cars:

                print(car.__dict__)


        elif choice == 3:
            break
if __name__ == "__main__":
    main()'''

from dao.ICarLeaseRepositoryImpl import ICarLeaseRepositoryImpl
from entity.Car import Car
from exception.CustomerNotFoundException import CustomerNotFoundException

import pyodbc

from exception.CarNotFoundException import CarNotFoundException
from exception.LeaseNotFoundException import LeaseNotFoundException

try:
    conn = pyodbc.connect(
        "DRIVER={SQL Server};"
        "SERVER=HOME;"  # Replace with your actual server name
        "DATABASE=CarRentalDB;"
        "Trusted_Connection=yes;"
    )
    print("✅ Connected successfully!")
    conn.close()
except Exception as e:
    print("❌ Connection failed:", e)


def main():
    repo = ICarLeaseRepositoryImpl()
    while True:
        print("1. Add Car\n2. List Available Cars\n3. Exit\n4. Return Car")
        choice = int(input("Enter your choice: "))

        if choice == 1:
            car_id = None,
            make = input("Make: ")
            model = input("Model: ")
            year = int(input("Year: "))
            rate = float(input("Daily Rate: "))  # you store the rate here
            status = "available"
            pcap = int(input("Passenger Capacity: "))
            ecap = float(input("Engine Capacity: "))

            # ✅ FIX: change dailyRate=dailyRate to dailyRate=rate
            car = Car(make=make, model=model, year=year, daily_rate=rate, available=status,
                      PassengerCapacity=pcap, EngineCapacity=ecap, car_id= None)
            repo.addCar(car)

        elif choice == 2:
            cars = repo.listAvailableCars()
            for car in cars:
                print(dict(zip([column[0] for column in repo.cursor.description], car)))
                '''print(car.__dict__)'''

        elif choice == 3:
            car_id = int(input("Enter Car ID to search: "))
            car = repo.findCarById(car_id)
            print(dict(zip([col[0] for col in repo.cursor.description], car)))


        elif choice == 4:
            try:
                customer_id = int(input("Enter Customer ID: "))
                customer = repo.findCustomerById(customer_id)
                print(dict(zip([col[0] for col in repo.cursor.description], customer)))

                while True:
                    try:
                        lease_id = int(input("Enter Lease ID: "))
                        repo.returnCar(lease_id)
                        print("✅ Car returned successfully.")
                        break  # end loop if success
                    except LeaseNotFoundException as e:
                        print("❌", e)
                    except Exception as e:
                        print("❌ Unexpected error:", e)
                        break

            except CustomerNotFoundException as e:
                print("❌", e)

        '''elif choice == 4:
            try:
                customer_id = int(input("Enter Customer ID: "))
                customer = repo.findCustomerById(customer_id)
                print(dict(zip([col[0] for col in repo.cursor.description], customer)))
            except CustomerNotFoundException as e:
                print("❌", e)

            while True:
                try:
                    lease_id = int(input("Enter Lease ID: "))
                    repo.returnCar(lease_id)
                    print("✅ Car returned successfully.")
                    break  # end loop if success
                except LeaseNotFoundException as e:
                    print("❌", e)
                except Exception as e:
                    print("❌ Unexpected error:", e)
                    break'''

        '''elif choice == 4:
        try:
            # Some code that might raise CarNotFoundException
            car = repo.findCarById(car_id)
        except CarNotFoundException as e:
            print(e)

    try:
        customer_id = int(input("Enter Customer ID: "))
        customer = repo.findCustomerById(customer_id)
        print(dict(zip([col[0] for col in repo.cursor.description], customer)))
    except CustomerNotFoundException as e:
        print("❌", e)

        while True:
            try:
                lease_id = int(input("Enter Lease ID: "))
                repo.returnCar(lease_id)
                print("✅ Car returned successfully.")
            except LeaseNotFoundException as e:
                print("❌", e)
            except Exception as e:
                print("❌ Unexpected error:", e)
                break  # ✅ only valid inside a loop'''


if __name__ == "__main__":
    main()


