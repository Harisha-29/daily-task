'''class Car:
    def __init__(self, vehicleID=None, make='', model='', year=0, dailyRate=0.0, status='', passengerCapacity=0, engineCapacity=0.0):
        self.__vehicleID = vehicleID
        self.__make = make
        self.__model = model
        self.__year = year
        self.__dailyRate = dailyRate
        self.__status = status
        self.__passengerCapacity = passengerCapacity
        self.__engineCapacity = engineCapacity

    # Getters and Setters
    def getVehicleID(self): return self.__vehicleID
    def setVehicleID(self, vehicleID): self.__vehicleID = vehicleID
    # Similarly for other attributes
'''

class Car:
    def __init__(self, car_id, make, model, year, daily_rate, available, PassengerCapacity, EngineCapacity):
        self.car_id = car_id
        self.make = make
        self.model = model
        self.year = year
        self.daily_rate = daily_rate
        self.available = available
        self.passengerCapacity = PassengerCapacity
        self.engineCapacity = EngineCapacity

    def getMake(self):
        return self.make

    def getModel(self):
        return self.model

    def getYear(self):
        return self.year

    def getDailyRate(self):
        return self.daily_rate

    def isAvailable(self):
        return self.available

    def getCarId(self):
        return self.car_id

    def getPassengerCapacity(self):
        return self.passengerCapacity

    def getEngineCapacity(self):
        return self.engineCapacity

    def getStatus(self):
        return self.available


