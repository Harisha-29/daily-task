class Lease:
    def __init__(self, leaseID=None, vehicleID=None, customerID=None, startDate=None, endDate=None, leaseType=''):
        self.__leaseID = leaseID
        self.__vehicleID = vehicleID
        self.__customerID = customerID
        self.__startDate = startDate
        self.__endDate = endDate
        self.__leaseType = leaseType

    # Getters and Setters
    def getLeaseID(self): return self.__leaseID
    def setLeaseID(self, leaseID): self.__leaseID = leaseID

    def getVehicleID(self): return self.__vehicleID
    def setVehicleID(self, vehicleID): self.__vehicleID = vehicleID

    def getCustomerID(self): return self.__customerID
    def setCustomerID(self, customerID): self.__customerID = customerID

    def getStartDate(self): return self.__startDate
    def setStartDate(self, startDate): self.__startDate = startDate

    def getEndDate(self): return self.__endDate
    def setEndDate(self, endDate): self.__endDate = endDate

    def getLeaseType(self): return self.__leaseType
    def setLeaseType(self, leaseType): self.__leaseType = leaseType
