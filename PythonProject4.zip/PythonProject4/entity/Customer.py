class Customer:
    def __init__(self, customerID=None, firstName='', lastName='', email='', phoneNumber=''):
        self.__customerID = customerID
        self.__firstName = firstName
        self.__lastName = lastName
        self.__email = email
        self.__phoneNumber = phoneNumber

    # Getters and Setters
    def getCustomerID(self): return self.__customerID
    def setCustomerID(self, customerID): self.__customerID = customerID

    def getFirstName(self): return self.__firstName
    def setFirstName(self, firstName): self.__firstName = firstName

    def getLastName(self): return self.__lastName
    def setLastName(self, lastName): self.__lastName = lastName

    def getEmail(self): return self.__email
    def setEmail(self, email): self.__email = email

    def getPhoneNumber(self): return self.__phoneNumber
    def setPhoneNumber(self, phoneNumber): self.__phoneNumber = phoneNumber
