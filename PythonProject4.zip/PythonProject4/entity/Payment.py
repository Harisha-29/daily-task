class Payment:
    def __init__(self, paymentID=None, leaseID=None, paymentDate=None, amount=0.0):
        self.__paymentID = paymentID
        self.__leaseID = leaseID
        self.__paymentDate = paymentDate
        self.__amount = amount

    # Getters and Setters
    def getPaymentID(self): return self.__paymentID
    def setPaymentID(self, paymentID): self.__paymentID = paymentID

    def getLeaseID(self): return self.__leaseID
    def setLeaseID(self, leaseID): self.__leaseID = leaseID

    def getPaymentDate(self): return self.__paymentDate
    def setPaymentDate(self, paymentDate): self.__paymentDate = paymentDate

    def getAmount(self): return self.__amount
    def setAmount(self, amount): self.__amount = amount
