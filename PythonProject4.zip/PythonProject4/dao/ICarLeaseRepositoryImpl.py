import pyodbc
from dao.ICarLeaseRepository import ICarLeaseRepository
from util.DBConnUtil import DBConnUtil
from entity.Car import Car
from entity.Customer import Customer
from entity.Lease import Lease
from entity.Payment import Payment
from exception.CarNotFoundException import CarNotFoundException
from exception.CustomerNotFoundException import CustomerNotFoundException
from exception.LeaseNotFoundException import LeaseNotFoundException

'''class ICarLeaseRepositoryImpl:
    def __init__(self):
        self.conn = DBConnUtil.getConnection()
        self.cursor = self.conn.cursor()'''

class ICarLeaseRepositoryImpl:
    def __init__(self):
        self.conn = DBConnUtil.getConnection()
        if self.conn is None:
            raise Exception("❌ Cannot create cursor: Database connection is None.")
        self.cursor = self.conn.cursor()


    # ----------------- CAR MANAGEMENT -----------------

    def addCar(self, car):
        query = """INSERT INTO Vehicle (make, model, year, dailyRate, status, passengerCapacity, engineCapacity)
                   VALUES (?, ?, ?, ?, ?, ?, ?)"""
        values = (car.getMake(), car.getModel(), car.getYear(), car.getDailyRate(),
                  car.getStatus(), car.getPassengerCapacity(), car.getEngineCapacity())
        self.cursor.execute(query, values)
        self.conn.commit()

    def removeCar(self, carID):
        self.cursor.execute("DELETE FROM Vehicle WHERE vehicleID = ?", (carID,))
        if self.cursor.rowcount == 0:
            raise CarNotFoundException()
        self.conn.commit()

    def listAvailableCars(self):
        self.cursor.execute("SELECT * FROM Vehicle WHERE status = 'available'")
        return self.cursor.fetchall()

    def listRentedCars(self):
        self.cursor.execute("SELECT * FROM Vehicle WHERE status = 'notAvailable'")
        return self.cursor.fetchall()

    def findCarById(self, carID):
        self.cursor.execute("SELECT * FROM Vehicle WHERE vehicleID = ?", (carID,))
        result = self.cursor.fetchone()
        if not result:
            raise CarNotFoundException()
        return result

    # ----------------- CUSTOMER MANAGEMENT -----------------

    def addCustomer(self, customer):
        query = """INSERT INTO Customer (firstName, lastName, email, phoneNumber)
                   VALUES (?, ?, ?, ?)"""
        values = (customer.getFirstName(), customer.getLastName(), customer.getEmail(), customer.getPhoneNumber())
        self.cursor.execute(query, values)
        self.conn.commit()

    def removeCustomer(self, customerID):
        self.cursor.execute("DELETE FROM Customer WHERE customerID = ?", (customerID,))
        if self.cursor.rowcount == 0:
            raise CustomerNotFoundException()
        self.conn.commit()

    def listCustomers(self):
        self.cursor.execute("SELECT * FROM Customer")
        return self.cursor.fetchall()

    def findCustomerById(self, customerID):
        self.cursor.execute("SELECT * FROM Customer WHERE customerID = ?", (customerID,))
        result = self.cursor.fetchone()
        if not result:
            raise CustomerNotFoundException()
        return result

    # ----------------- LEASE MANAGEMENT -----------------

    def createLease(self, customerID, carID, startDate, endDate):
        query = """INSERT INTO Lease (customerID, vehicleID, startDate, endDate, type)
                   VALUES (?, ?, ?, ?, ?)"""
        lease_type = "DailyLease" if (endDate - startDate).days <= 30 else "MonthlyLease"
        values = (customerID, carID, startDate, endDate, lease_type)
        self.cursor.execute(query, values)

        self.cursor.execute("UPDATE Vehicle SET status = 'notAvailable' WHERE vehicleID = ?", (carID,))
        self.conn.commit()

    def returnCar(self, leaseID):
        self.cursor.execute("SELECT vehicleID FROM Lease WHERE leaseID = ?", (leaseID,))
        result = self.cursor.fetchone()
        if not result:
            raise LeaseNotFoundException()
        carID = result.vehicleID

        self.cursor.execute("UPDATE Vehicle SET status = 'available' WHERE vehicleID = ?", (carID,))
        self.conn.commit()

    def listActiveLeases(self):
        self.cursor.execute("SELECT * FROM Lease WHERE endDate >= GETDATE()")
        return self.cursor.fetchall()

    def listLeaseHistory(self):
        self.cursor.execute("SELECT * FROM Lease")
        return self.cursor.fetchall()

    # ----------------- PAYMENT HANDLING -----------------

    def recordPayment(self, lease, amount):
        query = """INSERT INTO Payment (leaseID, paymentDate, amount)
                   VALUES (?, GETDATE(), ?)"""
        values = (lease.getLeaseID(), amount)
        self.cursor.execute(query, values)
        self.conn.commit()


from exception.CarNotFoundException import CarNotFoundException

def findCarById(self, carID):
    self.cursor.execute("SELECT * FROM Vehicle WHERE vehicleID = ?", (carID,))
    result = self.cursor.fetchone()
    if not result:
        raise CarNotFoundException()
    return result
